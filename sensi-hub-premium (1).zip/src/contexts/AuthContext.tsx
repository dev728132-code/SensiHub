import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, signInWithPopup, signOut } from 'firebase/auth';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import { UserProfile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  login: async () => {},
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = auth.onAuthStateChanged(async (firebaseUser) => {
      // Clean up previous profile listener if exists
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      setUser(firebaseUser);
      
      if (firebaseUser) {
        try {
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          
          // Use onSnapshot for real-time activation
          unsubscribeProfile = onSnapshot(userDocRef, (userDoc) => {
            if (!userDoc.exists()) {
              const newProfile: UserProfile = {
                userId: firebaseUser.uid,
                displayName: firebaseUser.displayName || 'Player',
                photoURL: firebaseUser.photoURL || '',
                membershipStatus: 'Free Member',
                activePlans: [],
                lastLogin: serverTimestamp(),
                createdAt: serverTimestamp(),
              };
              setDoc(userDocRef, newProfile).catch(e => console.error("Error creating profile:", e));
              setProfile(newProfile);
            } else {
              const data = userDoc.data() as UserProfile;
              setProfile(data);
            }
            setLoading(false);
          }, (error) => {
            console.error("Firestore onSnapshot error:", error);
            setLoading(false);
          });

          // Initial lastLogin update (one-shot)
          updateDoc(userDocRef, {
            lastLogin: serverTimestamp(),
            displayName: firebaseUser.displayName || 'Player',
            photoURL: firebaseUser.photoURL || '',
          }).catch(e => console.error("Error updating user info:", e));

        } catch (error) {
          console.error("Auth observer logic error:", error);
          setLoading(false);
        }
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  const login = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
