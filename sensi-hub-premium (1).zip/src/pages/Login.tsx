import { LogIn, Sparkles, Crosshair, ShieldCheck, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#050505] relative overflow-hidden"
    >
      {/* Background Animated Effects */}
      <div className="absolute inset-0 z-0">
         <img 
           src="/src/assets/images/sensi_hub_hero_bg_1780809282844.png" 
           alt="Hero Background" 
           className="w-full h-full object-cover opacity-20 grayscale brightness-50"
         />
         <div className="absolute inset-0 bg-gradient-to-b from-black via-black/40 to-black" />
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-yellow-500/10 rounded-full blur-[120px] opacity-20" />
         
         {/* Grid Background */}
         <div className="absolute inset-0 opacity-[0.03]" 
              style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} 
         />
      </div>
      
      <div className="z-10 w-full max-w-sm space-y-12 text-center">
        <motion.div 
          initial={{ scale: 0.5, opacity: 0, rotate: -180 }}
          animate={{ scale: 1, opacity: 1, rotate: 0 }}
          transition={{ duration: 0.8, ease: "backOut" }}
          className="mx-auto w-24 h-24 bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-600 rounded-[2rem] p-[2px] shadow-[0_20px_50px_rgba(234,179,8,0.25)] border border-yellow-400/50"
        >
          <div className="w-full h-full bg-[#050505] rounded-[1.8rem] flex items-center justify-center">
            <Crosshair className="w-12 h-12 text-yellow-500" />
          </div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="space-y-4"
        >
          <h1 className="text-3xl font-black text-white uppercase tracking-tighter leading-none">
            Gaming <span className="text-yellow-500">Experience</span>
          </h1>
          <p className="text-gray-500 text-[10px] font-bold uppercase tracking-[0.3em] leading-relaxed">
            Ultimate Pro Sensitivity Generator
          </p>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-gray-900/40 border border-gray-800 rounded-[2.5rem] p-8 backdrop-blur-xl space-y-8 relative overflow-hidden"
        >
          {/* Subtle Accent Glow */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-yellow-500/10 rounded-full blur-2xl" />
          
          <div className="space-y-3 relative z-10">
            <h2 className="text-xl font-black text-white uppercase tracking-tight">Access The Vault</h2>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest leading-none">Sign in to unlock elite configs</p>
          </div>

          <div className="space-y-4">
             <button 
               onClick={login}
               className="group relative w-full h-16 bg-white hover:bg-gray-100 text-black font-black flex items-center justify-center space-x-3 rounded-2xl transition-all shadow-[0_10px_20px_rgba(0,0,0,0.2)] active:scale-95 overflow-hidden"
             >
               <div className="absolute inset-0 bg-gradient-to-r from-transparent via-black/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
               <svg viewBox="0 0 24 24" className="w-6 h-6" aria-hidden="true">
                 <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                 <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                 <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                 <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
               </svg>
               <span className="uppercase tracking-widest text-xs">Continue with Google</span>
             </button>

             <div className="flex justify-center items-center gap-6 opacity-30 pt-4">
                <ShieldCheck className="w-5 h-5 text-gray-400" />
                <Zap className="w-5 h-5 text-gray-400" />
                <Sparkles className="w-5 h-5 text-gray-400" />
             </div>
          </div>
        </motion.div>

        <motion.div 
           initial={{ opacity: 0 }}
           animate={{ opacity: 0.4 }}
           transition={{ delay: 1 }}
           className="text-[9px] font-mono text-white tracking-[0.2em] uppercase"
        >
           Encrypted Connection Established
        </motion.div>
      </div>
    </motion.div>
  );
}
